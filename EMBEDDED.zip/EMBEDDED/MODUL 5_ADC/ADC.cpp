// ADC -> DAC ESP32

const int adcPin = 34;   // Input ADC
const int dacPin = 25;   // DAC1 Output

void setup() {
  Serial.begin(115200);
}

void loop() {
  // Baca ADC (0 - 4095)
  int adcValue = analogRead(adcPin);

  // Konversi ke DAC (0 - 255)
  int dacValue = map(adcValue, 0, 4095, 0, 255);

  // Keluarkan ke DAC
  dacWrite(dacPin, dacValue);

  // Monitoring
  float voltageADC = adcValue * 3.3 / 4095.0;
  float voltageDAC = dacValue * 3.3 / 255.0;

  Serial.print("ADC = ");
  Serial.print(adcValue);
  Serial.print(" (");
  Serial.print(voltageADC, 2);
  Serial.print(" V)   DAC = ");
  Serial.print(dacValue);
  Serial.print(" (");
  Serial.print(voltageDAC, 2);
  Serial.println(" V)");

  delay(100);
}