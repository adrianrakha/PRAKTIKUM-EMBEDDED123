// ADC -> DAC + LED Indicator
// Potensiometer -> GPIO34
// DAC Output -> GPIO25
// LED -> GPIO2

const int adcPin = 34;
const int dacPin = 25;
const int ledPin = 2;

const float threshold = 1.5; // Tegangan ambang LED

void setup() {
  Serial.begin(115200);

  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);
}

void loop() {

  // Baca ADC (0 - 4095)
  int adcValue = analogRead(adcPin);

  // Hitung tegangan ADC
  float voltageADC = adcValue * 3.3 / 4095.0;

  // Konversi ADC ke DAC (0 - 255)
  int dacValue = map(adcValue, 0, 4095, 0, 255);

  // Keluarkan ke DAC
  dacWrite(dacPin, dacValue);

  // Hitung tegangan DAC
  float voltageDAC = dacValue * 3.3 / 255.0;

  // Kontrol LED berdasarkan tegangan ADC
  if (voltageADC >= threshold) {
    digitalWrite(ledPin, HIGH);
  } else {
    digitalWrite(ledPin, LOW);
  }

  // Tampilkan data ke Serial Monitor
  Serial.print("ADC Value : ");
  Serial.print(adcValue);

  Serial.print(" | ADC Voltage : ");
  Serial.print(voltageADC, 2);
  Serial.print(" V");

  Serial.print(" | DAC Value : ");
  Serial.print(dacValue);

  Serial.print(" | DAC Voltage : ");
  Serial.print(voltageDAC, 2);
  Serial.print(" V");

  Serial.print(" | LED : ");
  if (voltageADC >= threshold) {
    Serial.println("ON");
  } else {
    Serial.println("OFF");
  }

  delay(100);
}